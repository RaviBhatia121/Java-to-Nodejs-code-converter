package com.sparta.engineering72.sakilaproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SakilaProjectApplication {

    public static void main(String[] args) {
        SpringApplication.run(SakilaProjectApplication.class, args);
    }

}
